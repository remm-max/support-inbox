# Drop 1: apply guide

Unzip into your project root (the folder containing `api/` and `app/`), overwriting files:

    unzip -o drop1.zip -d /tmp/drop1-unpacked
    cp -r /tmp/drop1-unpacked/drop1/api/src/. api/src/
    cp -r /tmp/drop1-unpacked/drop1/app/src/. app/src/

Then restart the API (Ctrl+C, `npm run dev` in api/) and reload Expo (press `r`).
No new npm packages and no database migration are needed.
