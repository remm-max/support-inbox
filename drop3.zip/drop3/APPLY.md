# Drop 3: AI draft replies (free providers supported)

From your project root:

    unzip -o drop3.zip -d /tmp/drop3-unpacked
    cp -r /tmp/drop3-unpacked/drop3/api/. api/
    cp -r /tmp/drop3-unpacked/drop3/app/. app/

No new npm packages and no migration. Edit api/.env (never commit it).

Free, no card (Groq):
    AI_PROVIDER=groq
    GROQ_API_KEY=gsk_...        # console.groq.com -> API Keys

Free testing with no account at all:
    AI_PROVIDER=mock

Restart the API (Ctrl+C, npm run dev) and reload the app (press r).
