# Drop 2: apply guide

From your project root (folder containing api/ and app/):

    unzip -o drop2.zip -d /tmp/drop2-unpacked
    cp -r /tmp/drop2-unpacked/drop2/api/. api/
    cp -r /tmp/drop2-unpacked/drop2/app/. app/

(`api/.env.example` is copied too; it does NOT overwrite your `.env`.)

API:
    cd api
    npm install bcryptjs@^3 jsonwebtoken
    npm install -D @types/jsonwebtoken
    echo "JWT_SECRET=$(openssl rand -hex 32)" >> .env
    npm run migrate        # creates the users table
    npm run dev

App:
    cd ../app
    npx expo install expo-secure-store
    npx expo start --web   # (phone: same command you used before)
